//
//  DireccionView.swift
//  UsuarioView
//
//  Created by Alumno on 13/10/23.
//

import SwiftUI

struct DireccionView: View {
    let Direccion: String = "Av. Eugenio Garza Sada\nCol. Nueva Estrada \nCataluña 208\nNuevo Leon, Monterrey\n64840"
    let referencias: String = "Casa azul enseguida de Farmacia Benavides"
    var body: some View {
        VStack{
            List{
                VStack{
                    Text("Dirección")
                        .font(.system(size: 14))
                        .frame(maxWidth:.infinity, alignment:.leading)
                    Text("\(Direccion)")
                        .foregroundColor(Color("fontBlue"))
                        .font(.system(size:15))
                        .frame(maxWidth:.infinity, alignment:.leading)
                }.listRowBackground(Color("rowGray"))
                VStack{
                    Text("Referencia")
                        .frame(maxWidth:.infinity, alignment:.leading)
                        .font(.system(size: 14))
                    Text("\(referencias)")
                        .foregroundColor(Color("fontBlue"))
                        .font(.system(size: 15))
                        .frame(maxWidth:.infinity, alignment:.leading)
                }.listRowBackground(Color("rowGray"))
            }.listStyle(.insetGrouped)
        }
    }
}

struct DireccionView_Previews: PreviewProvider {
    static var previews: some View {
        DireccionView()
    }
}
