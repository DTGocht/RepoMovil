//
//  ContentView.swift
//  UsuarioView
//
//  Created by Alumno on 13/10/23.
//

import SwiftUI

struct ContentView: View {
    var y:CGFloat = -60
    var body: some View {
        VStack() {
            Text("Manuel Ortiz")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top, 40)
                .padding(.bottom, -35)
            CelularView()
                .padding(.bottom, y)
            DireccionView()
                .padding(.top, y)
                .padding(.bottom, y)
            DineroView()
                .padding(.top, y)
            ButtonView()
                .padding(.top, y)
                .offset(y: -70)
        }.scrollContentBackground(.hidden)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
