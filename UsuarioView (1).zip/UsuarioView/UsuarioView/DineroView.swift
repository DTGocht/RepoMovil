//
//  DineroView.swift
//  UsuarioView
//
//  Created by Alumno on 13/10/23.
//

import SwiftUI

struct DineroView: View {
    let Dinero: Double = 500
    var body: some View {
        VStack{
            List{
            VStack{
                Text("Cantidad a cobrar")
                    .font(.system(size: 14))
                    .frame(maxWidth:.infinity, alignment:.leading)
                Text("$ \(Dinero, specifier: "%0.2f")")
                    .foregroundColor(Color("moneyBlue"))
                    .font(.system(size: 26))
                    .frame(maxWidth:.infinity, alignment:.leading)
            }.listRowBackground(Color("rowGray"))
            
        }.listStyle(.insetGrouped)
                

        }
    }
}

struct DineroView_Previews: PreviewProvider {
    static var previews: some View {
        DineroView()
    }
}
