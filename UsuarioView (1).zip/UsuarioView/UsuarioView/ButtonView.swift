//
//  ButtonView.swift
//  UsuarioView
//
//  Created by Alumno on 13/10/23.
//

import SwiftUI

struct ButtonView: View {
    @State private var buttonExists = true
    @State private var alert = false
    var body: some View {
        VStack{
            if (buttonExists == true){
                Button{
                    alert = true
                }label:{
                    Image("Check")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .padding(.horizontal, 150)
                }
                .buttonStyle(.borderedProminent)
                .tint(Color("buttonGreen"))
                .alert(isPresented: $alert){
                    Alert(title: Text("¿Confirmar cobrado?"),
                          message: Text("Una vez confirmado, no se puede deshacer"),
                          primaryButton:
                            .destructive(Text("Sí"))
                            {
                        self.buttonExists = false
                            },
                          secondaryButton:
                            .cancel(Text("No"))
                    )
                }
                Button{
                    alert = true
                }label:{
                    Image("Cross")
                        .resizable()
                        .background(.red)
                        .frame(width: 60, height: 60)
                        .padding(.horizontal, 150)
                }
                .buttonStyle(.borderedProminent)
                .tint(Color("buttonRed"))
                .alert(isPresented: $alert){
                    Alert(title: Text("¿Confirmar cobrado?"),
                          message: Text("Una vez confirmado, no se puede deshacer"),
                          primaryButton: .destructive(Text("Sí")){
                        self.buttonExists = false
                    },
                          secondaryButton: .cancel(Text("No"))
                    )
                }
            }
            }
        
    }
}

struct ButtonView_Previews: PreviewProvider {
    static var previews: some View {
        ButtonView()
    }
}
