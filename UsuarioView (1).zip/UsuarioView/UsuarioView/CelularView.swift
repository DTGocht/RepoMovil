//
//  CelularView.swift
//  UsuarioView
//
//  Created by Alumno on 13/10/23.
//

import SwiftUI

struct CelularView: View {
    let celular: String = "+52 662 307 6006"
    let Casa: String = "250 281 0087"
    let cel_ref: String = "+52 662 409 8183"
    var body: some View {
        VStack{
            List{
                VStack{
                    Text("Celular")
                        .font(.system(size:14))
                        .frame(maxWidth:.infinity, alignment:.leading)
                    Text("\(celular)")
                        .foregroundColor(Color("fontBlue"))
                        .font(.system(size:14))
                        .frame(maxWidth:.infinity, alignment:.leading)
                }.listRowBackground(Color("rowGray"))
                VStack{
                    Text("Casa")
                        .font(.system(size:14))
                        .frame(maxWidth:.infinity, alignment:.leading)
                    Text("\(Casa)")
                        .foregroundColor(Color("fontBlue"))
                        .font(.system(size:15))
                        .frame(maxWidth:.infinity, alignment:.leading)
                }.listRowBackground(Color("rowGray"))
                VStack{
                    Text("Celular referente")
                        .font(.system(size: 14))
                        .frame(maxWidth:.infinity, alignment:.leading)
                    Text("\(cel_ref)")
                        .foregroundColor(Color("fontBlue"))
                        .font(.system(size: 15))
                        .frame(maxWidth:.infinity, alignment:.leading)
                }.listRowBackground(Color("rowGray"))
            }.listStyle(.insetGrouped)
        }
    }
}

struct CelularView_Previews: PreviewProvider {
    static var previews: some View {
        CelularView()
    }
}
